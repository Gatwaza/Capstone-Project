// Novice — CPR-AI Coach
// MediaPipe Pose bridge — BlazePose via CDN global (not ES module import)

window._novicePoseLandmarks = null;
window._novicePoseTimestamp = 0;

function initPoseBridge() {
  // Use the global Pose already available from CDN script tag
  if (typeof Pose === 'undefined') {
    console.warn('[NovicePose] Pose not loaded yet, retrying...');
    setTimeout(initPoseBridge, 300);
    return;
  }

  const pose = new Pose({
    locateFile: (file) =>
      `https://cdn.jsdelivr.net/npm/@mediapipe/pose@0.5.1675469404/${file}`,
  });

  pose.setOptions({
    modelComplexity: 1,
    smoothLandmarks: true,
    enableSegmentation: false,
    minDetectionConfidence: 0.5,
    minTrackingConfidence: 0.5,
  });

  pose.onResults((results) => {
    if (results.poseLandmarks) {
      window._novicePoseLandmarks = results.poseLandmarks;
      window._novicePoseTimestamp = Date.now();
    }
  });

  function findVideoAndStart() {
    const video = document.querySelector('video');
    if (!video) {
      setTimeout(findVideoAndStart, 500);
      return;
    }

    async function sendFrame() {
      try {
        if (!video.paused && !video.ended && video.readyState >= 2) {
          await pose.send({ image: video });
        }
      } catch (e) {
        // ignore single-frame errors
      }
      requestAnimationFrame(sendFrame);
    }

    sendFrame();
    console.log('[NovicePose] MediaPipe bridge active — sending frames');
  }

  findVideoAndStart();
}

// Also load the MediaPipe script explicitly so we control the version
const script = document.createElement('script');
script.src = 'https://cdn.jsdelivr.net/npm/@mediapipe/pose@0.5.1675469404/pose.js';
script.crossOrigin = 'anonymous';
script.onload = initPoseBridge;
script.onerror = () => console.error('[NovicePose] Failed to load MediaPipe');
document.head.appendChild(script);