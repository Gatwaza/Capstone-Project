// Novice — CPR-AI Coach
// GNU General Public License v3.0
// Copyright (C) 2024 Jean Robert Gatwaza — African Leadership University
//
// Web ML inference — calls hosted CNN_BiLSTM API.
// Returns isSimulated=true (no accumulation) when the CNN-BiLSTM API is unreachable.
//
// FIX (2026-06): allClassScores map keys are now namespaced with a task prefix
// ('rate_', 'depth_', 'recoil_') to prevent Dart map-literal duplicate-key
// collisions.  When two or more tasks simultaneously predict 'Correct', the
// bare-key version silently drops all but the last entry because Dart map
// literals use last-write-wins for duplicate keys.  The result was that
// session_provider's .where() filter for rate-class tallying could match a
// 'Correct' key that actually belonged to depth or recoil — inflating
// rate_precision/recall/f1 to 1.0 even when rate_accuracy was 0.
//
// The fix is two-sided:
//   1. Here: keys in allClassScores are 'rate_Correct', 'depth_Too_Deep', etc.
//   2. session_provider.dart: the .where() filters use the prefixed keys.
// rateLabel / depthLabel / recoilLabel are still set as plain 'Correct' /
// 'Too_Fast' etc. — those are the values compared for accuracy and the labels
// stored in _xClassCounts via the direct label path, which never touches
// allClassScores.

import 'dart:async';
import 'dart:collection';
// ignore: avoid_web_libraries_in_flutter
import 'dart:js' as js;

import '../../core/constants/app_constants.dart';
import '../../core/utils/landmark_math.dart';
import '../../models/landmark_frame.dart';
import '../../models/session_model.dart';
import 'cpr_api_service.dart';

class InferenceServiceWeb {
  final _frameBuffer   = ListQueue<List<double>>();
  final _wristYHistory = ListQueue<_TimedSample>();
  final _api           = CprApiService();

  InferenceResult? _lastApiResult;
  DateTime? _lastApiCallAt;
  bool _apiCallInFlight = false;
  static const Duration _apiCallInterval = Duration(milliseconds: 600);
  static const Duration _apiResultMaxAge = Duration(milliseconds: 1500);

  double _shoulderWidthPxSum = 0;
  int _shoulderWidthSamples  = 0;
  static const int _depthCalibFrames = 30;

  bool get isModelLoaded => _api.isReachable;

  Future<void> init() async {
    await _api.checkHealth();
  }

  Future<void> _maybeCallApi(LandmarkFrame frame) async {
    if (!_api.isReachable) return;
    if (_apiCallInFlight) return;
    if (_frameBuffer.length < AppConstants.temporalWindowFrames) return;

    final now = DateTime.now();
    if (_lastApiCallAt != null &&
        now.difference(_lastApiCallAt!) < _apiCallInterval) {
      return;
    }

    _apiCallInFlight = true;
    _lastApiCallAt = now;
    try {
      final sequence   = _frameBuffer.toList();
      final prediction = await _api.predict(sequence);
      if (prediction != null) {
        print('[InferenceServiceWeb] API → ${prediction.resolvedLabel} '
              '(${prediction.resolvedConfidence.toStringAsFixed(2)})');

        // FIX: prefix each key with its task name so that simultaneous
        // 'Correct' predictions from different tasks do not overwrite each
        // other in the map literal.  Before this fix, a frame where rate,
        // depth, and recoil all predicted 'Correct' produced:
        //   {'Correct': rateConf, 'Correct': depthConf, 'Correct': recoilConf}
        // Dart keeps only the last value, so the map had a single 'Correct'
        // key.  session_provider's rate-class .where() filter then saw
        // 'Correct' and tallied it as a rate-correct hit even on sessions
        // where rate was wrong 100% of the time (rate_accuracy=0) — because
        // depth's 'Correct' entry survived in the map and matched the filter.
        //
        // With prefixed keys the map always has exactly 3 distinct entries:
        //   'rate_Correct', 'depth_Correct', 'recoil_Correct'
        // and the filters in session_provider.dart use the matching prefixes.
        _lastApiResult = InferenceResult(
          timestamp:           DateTime.now(),
          topClassIndex:       0,
          topClassLabel:       prediction.resolvedLabel,
          topClassConfidence:  prediction.resolvedConfidence,
          allClassScores: {
            // Prefixed keys — no collision even when all three are 'Correct'.
            'rate_${prediction.rateLabel}':   prediction.rateConfidence,
            'depth_${prediction.depthLabel}': prediction.depthConfidence,
            'recoil_${prediction.recoilLabel}': prediction.recoilConfidence,
          },
          currentBpm:          _estimateBpm(),
          estimatedDepthCm:    _estimateDepthCm(frame),
          elbowAngleMean:      (frame.leftElbowAngle + frame.rightElbowAngle) / 2,
          spineVerticalityDeg: frame.spineVerticality,
          rateAccuracy:        prediction.rateLabel   == 'Correct' ? 1.0 : 0.0,
          rateConfidence:      prediction.rateConfidence,
          depthAccuracy:       prediction.depthLabel  == 'Correct' ? 1.0 : 0.0,
          depthConfidence:     prediction.depthConfidence,
          recoilAccuracy:      prediction.recoilLabel == 'Correct' ? 1.0 : 0.0,
          recoilConfidence:    prediction.recoilConfidence,
          // Plain labels — used for accuracy comparison and class-count tallying
          // in session_provider; they do NOT go into allClassScores.
          rateLabel:   prediction.rateLabel,
          depthLabel:  prediction.depthLabel,
          recoilLabel: prediction.recoilLabel,
          isSimulated:         false,
        );
      }
    } finally {
      _apiCallInFlight = false;
    }
  }

  InferenceResult infer(LandmarkFrame frame) {
    final features = _buildFeatures(frame);

    _frameBuffer.addLast(features);
    while (_frameBuffer.length > AppConstants.temporalWindowFrames) {
      _frameBuffer.removeFirst();
    }

    _wristYHistory.addLast(_TimedSample(frame.capturedAt, frame.wristMidY));
    while (_wristYHistory.length > AppConstants.bpmHistoryLength) {
      _wristYHistory.removeFirst();
    }

    _updateDepthCalibration(frame);

    final bpm   = _estimateBpm();
    final depth = _estimateDepthCm(frame);

    unawaited(_maybeCallApi(frame));

    final cached = _lastApiResult;
    if (cached != null &&
        DateTime.now().difference(cached.timestamp) < _apiResultMaxAge) {
      return cached.copyWith(currentBpm: bpm, estimatedDepthCm: depth);
    }

    return InferenceResult(
      timestamp:           DateTime.now(),
      topClassIndex:       0,
      topClassLabel:       'model_unavailable',
      topClassConfidence:  0.0,
      allClassScores:      const {},
      currentBpm:          bpm,
      estimatedDepthCm:    depth,
      elbowAngleMean:      (frame.leftElbowAngle + frame.rightElbowAngle) / 2,
      spineVerticalityDeg: frame.spineVerticality,
      isSimulated:         true,
    );
  }

  List<double> _buildFeatures(LandmarkFrame frame) {
    return LandmarkMath.buildFeatureVector(
      leftElbowAngle:     frame.leftElbowAngle,
      rightElbowAngle:    frame.rightElbowAngle,
      spineVerticality:   frame.spineVerticality,
      wristY:             frame.wristMidY,
      wristVelocityY:     frame.wristVelocityY,
      wristAccelerationY: frame.wristAccelerationY,
      normalizedDepth: LandmarkMath.normalizedWristDisplacement(
        frame.wristMidY, frame.leftShoulderY, frame.leftHipY,
      ),
      shoulderWidth:    frame.shoulderWidth,
      meanConfidence:   frame.meanLandmarkConfidence,
      leftElbowVisible:
          frame.leftElbowVisibility > AppConstants.minLandmarkVisibility,
      rightElbowVisible:
          frame.rightElbowVisibility > AppConstants.minLandmarkVisibility,
    );
  }

  void _updateDepthCalibration(LandmarkFrame frame) {
    if (frame.shoulderWidth > 0.05) {
      _shoulderWidthPxSum += frame.shoulderWidth;
      _shoulderWidthSamples++;
    }
  }

  double _estimateDepthCm(LandmarkFrame frame) {
    final normDisp = LandmarkMath.normalizedWristDisplacement(
      frame.wristMidY,
      (frame.leftShoulderY + frame.rightShoulderY) / 2,
      (frame.leftHipY + frame.rightHipY) / 2,
    );

    double torsoHeightCm;
    if (_shoulderWidthSamples >= _depthCalibFrames) {
      final meanShoulderWidthNorm = _shoulderWidthPxSum / _shoulderWidthSamples;
      torsoHeightCm = (meanShoulderWidthNorm * AppConstants.normToPhysicalCmScale)
                      / AppConstants.shoulderWidthToTorsoRatio;
    } else {
      torsoHeightCm = AppConstants.fallbackTorsoHeightCm;
    }

    return (normDisp * torsoHeightCm).clamp(0.0, 10.0);
  }

  double _estimateBpm() {
    if (_wristYHistory.length < 10) return 0;
    final samples    = _wristYHistory.toList();
    final velocities = <double>[];
    for (int i = 1; i < samples.length; i++) {
      velocities.add(samples[i].value - samples[i - 1].value);
    }
    final peaks = <DateTime>[];
    for (int i = 1; i < velocities.length - 1; i++) {
      if (velocities[i] > velocities[i - 1] &&
          velocities[i] > velocities[i + 1] &&
          velocities[i] > 0.005) {
        peaks.add(samples[i + 1].timestamp);
      }
    }
    if (peaks.length < 2) return 0;
    double totalMs = 0;
    for (int i = 1; i < peaks.length; i++) {
      totalMs += peaks[i].difference(peaks[i - 1]).inMilliseconds;
    }
    final meanMs = totalMs / (peaks.length - 1);
    return meanMs <= 0 ? 0 : (60000 / meanMs).clamp(0, 200);
  }

  void dispose() {}
}

class _TimedSample {
  final DateTime timestamp;
  final double   value;
  _TimedSample(this.timestamp, this.value);
}